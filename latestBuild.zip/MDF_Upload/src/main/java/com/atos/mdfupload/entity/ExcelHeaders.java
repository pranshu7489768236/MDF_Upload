package com.atos.mdfupload.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MDF_Excel_Headers")
public class ExcelHeaders {
	@Id
	@Column(name = "Header_Type")
	private String headerType;

	@Column(name = "ExcelHeaders")
	private String headerList[];

	public String getHeaderType() {
		return headerType;
	}

	public void setHeaderType(String headerType) {
		this.headerType = headerType;
	}

	public String[] getHeaderList() {
		return headerList;
	}

	public void setHeaderList(String[] headerList) {
		this.headerList = headerList;
	}

}
