package com.atos.mdfupload.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.atos.mdfupload.coustom.exception.ResponseGenrator;

public interface StudentService {
	public List<ResponseGenrator> save(MultipartFile file) throws IOException;
	
	public Object dumpTempToProduction();
}
