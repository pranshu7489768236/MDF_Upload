package com.atos.mdfupload.service;

import com.atos.mdfupload.entity.ExcelHeaders;

public interface MDFUploadHeaders {

	ExcelHeaders uploadHeaders(ExcelHeaders excelHeaders);

	ExcelHeaders getData();

}
