package com.atos.mdfupload.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atos.mdfupload.entity.ExcelHeaders;
import com.atos.mdfupload.repository.UploadExcelHeaders;
import com.atos.mdfupload.service.MDFUploadHeaders;
@Service
public class MDFUploadHeadersImpl implements MDFUploadHeaders {
	
	@Autowired
	UploadExcelHeaders uploadExcel; 

	@Override
	public ExcelHeaders uploadHeaders(ExcelHeaders excelHeaders) {
		return uploadExcel.save(excelHeaders);
	}

	@Override
	public ExcelHeaders getData() {
		return uploadExcel.findByS_No();
	}

}
