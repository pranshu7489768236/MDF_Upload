package com.atos.mdfupload.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.atos.mdfupload.entity.ExcelHeaders;

@Repository
public interface UploadExcelHeaders extends JpaRepository<ExcelHeaders, Integer> {
    @Query("select i from ExcelHeaders i where i.headerType='MDF_HEADERS'")
	ExcelHeaders findByS_No();

}
