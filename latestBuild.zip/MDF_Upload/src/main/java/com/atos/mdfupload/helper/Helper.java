package com.atos.mdfupload.helper;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.atos.mdfupload.coustom.exception.ResponseGenrator;
import com.atos.mdfupload.coustom.exception.UserResponse;
import com.atos.mdfupload.entity.ExcelHeaders;

public class Helper {
	private static int totalNumberOfExcelRecord;
	private static UserResponse response = new UserResponse();
	private static List<String> dbHeaders = new ArrayList<String>();
	private static List<XSSFCell> excelHeaders = new ArrayList<XSSFCell>();
	public static List<UserResponse> userResponse = new ArrayList<UserResponse>();
    public static List<ResponseGenrator>xlsxFileUploadStatus=new ArrayList<ResponseGenrator>();
	// check that file is of excel type or not
	public static boolean checkExcelFormat(MultipartFile file) {
		userResponse = new ArrayList<UserResponse>();
		String contentType = file.getContentType();

		if (contentType.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
			return true;
		} else {
			response.setSms("Please upload valid .XLSX Format");
			response.setStatus(404);
			userResponse.add(response);
			return false;
		}

	}

	// convert excel to list of products

	public static List<com.atos.mdfupload.coustom.exception.ResponseGenrator> convertExcelToListOfProduct(InputStream is) {
		List<ResponseGenrator> list = new ArrayList<>();

		try {

			XSSFWorkbook workbook = new XSSFWorkbook(is);
			XSSFSheet sheet = workbook.getSheet("Sheet1");
			totalNumberOfExcelRecord=sheet.getLastRowNum();
			excelHeaders.add(sheet.getRow(0).getCell(0));
			excelHeaders.add(sheet.getRow(0).getCell(1));
			excelHeaders.add(sheet.getRow(0).getCell(2));
			excelHeaders.add(sheet.getRow(0).getCell(3));
			excelHeaders.add(sheet.getRow(0).getCell(4));
			if (isHeadersVaild(excelHeaders)) {
				int rowNumber = 0;
				java.util.Iterator<Row> iterator = sheet.iterator();

				while (iterator.hasNext()) {
					Row row = iterator.next();

					if (rowNumber == 0) {
						rowNumber++;
						continue;
					}

					java.util.Iterator<Cell> cells = row.iterator();

					int cid = 0;

					ResponseGenrator p = new ResponseGenrator();

					while (cells.hasNext()) {
						Cell cell = cells.next();

						switch (cid) {

						case 0:
							p.setName(cell.getStringCellValue());
							break;
						case 1:
							p.setDob((cell.getDateCellValue()));
							break;

						case 2:
							p.setAge((int) cell.getNumericCellValue());
							break;
						case 3:
							p.setStandered((int) cell.getNumericCellValue());
							break;
						case 4:
							p.setSchoolName(cell.getStringCellValue());
						default:
							break;
						}
						cid++;
						

					}
					p.setStatus("SUCCESS");
					list.add(p);

				}
			} else {
				response.setSms("Please Meantion Proper Header's [You Can't Change Templet Header's]");
				response.setStatus(404);
				userResponse.add(response);
			}

		} catch (Exception e) {
			response.setSms("Please Enter Mandatory Filed's data");
			response.setStatus(404);
			userResponse.add(response);
		}
		if(list.size()!=totalNumberOfExcelRecord) {
			list=new ArrayList<ResponseGenrator>();
		}else {
			response.setSms("File uploaded Successfully");
			response.setStatus(200);
			userResponse.add(response);
		}
		return list;

	}

	public static void getDbHeaders(ExcelHeaders headers) {
		dbHeaders = new ArrayList<String>();
		String[] headerList = headers.getHeaderList();
		for (String t : headerList) {
			dbHeaders.add(t);
		}

	}

	private static boolean isHeadersVaild(List<XSSFCell> excelHeaders) {
		int headerCount = 0;
		for (int count = 0; count < dbHeaders.size(); count++) {
			if ((excelHeaders.get(count) + "").equals(dbHeaders.get(count))) {
				System.out.println(excelHeaders.get(count) + " " + dbHeaders.get(count));
				++headerCount;
			}
		}
		System.out.println("head Count " + headerCount);
		if (headerCount == dbHeaders.size()) {
			return true;
		} else {
			return false;
		}

	}

}
