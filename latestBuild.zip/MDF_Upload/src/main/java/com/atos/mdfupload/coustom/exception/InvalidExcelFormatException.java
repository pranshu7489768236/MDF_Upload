package com.atos.mdfupload.coustom.exception;

public class InvalidExcelFormatException extends RuntimeException {

	public InvalidExcelFormatException(String message) {
		super(message);

	}

}
