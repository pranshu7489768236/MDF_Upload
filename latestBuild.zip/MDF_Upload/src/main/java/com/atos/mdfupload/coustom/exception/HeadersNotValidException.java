package com.atos.mdfupload.coustom.exception;

public class HeadersNotValidException extends RuntimeException{

	public HeadersNotValidException(String message) {
		super(message);
		
	}

}
