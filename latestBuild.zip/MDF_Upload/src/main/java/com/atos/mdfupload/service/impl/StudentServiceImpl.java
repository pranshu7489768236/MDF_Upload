package com.atos.mdfupload.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.atos.mdfupload.helper.Helper;
import com.atos.mdfupload.repository.ResponseGenrator;
import com.atos.mdfupload.repository.StudentRepo;
import com.atos.mdfupload.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService {
	private List<com.atos.mdfupload.coustom.exception.ResponseGenrator> products = new ArrayList<com.atos.mdfupload.coustom.exception.ResponseGenrator>();
	@Autowired
	StudentRepo repo;

	@Autowired
	ResponseGenrator response;

	@Override
	public List<com.atos.mdfupload.coustom.exception.ResponseGenrator> save(MultipartFile file) throws IOException {
		products = Helper.convertExcelToListOfProduct(file.getInputStream());
		List<com.atos.mdfupload.coustom.exception.ResponseGenrator> saveAll = response.saveAll(products);
		if (saveAll != null) {
			dumpTempToProduction();
			
		}
		return saveAll;

	}

	@Override
	public Object dumpTempToProduction() {
		return repo.dumpTempToProduction();
	}
}
