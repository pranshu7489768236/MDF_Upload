package com.atos.mdfupload.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.atos.mdfupload.entity.StudentEntity;

@Repository
public interface StudentRepo extends JpaRepository<StudentEntity, Integer> {
	@Modifying
	@Transactional
	@Query("insert into StudentEntity(name, dob, age,standered,schoolName)\r\n" + 
			"    select name, dob, age,standered,schoolName\r\n" + 
			"    from ResponseGenrator t1\r\n" + 
			"    where not exists (select 1 from StudentEntity t2 where t2.name = t1.name)\r\n" + 
			"")
	 public Object dumpTempToProduction();

//	@Modifying(clearAutomatically = true)
//	@Transactional
//	@Query("CREATE TABLE ResponseGenrator (name varchar(20),dob date,age int,standered int,schoolName varchar(20),status varchar(20));")
//	public void createTeamp();
//	@Transactional
//	@Query("DROP TABLE ResponseGenrator")
//	public void dropTempTable(String tableName);
}
