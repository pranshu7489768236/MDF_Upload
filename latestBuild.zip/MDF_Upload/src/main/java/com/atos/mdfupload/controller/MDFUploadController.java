package com.atos.mdfupload.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.atos.mdfupload.entity.ExcelHeaders;
import com.atos.mdfupload.helper.Helper;
import com.atos.mdfupload.service.MDFUploadHeaders;

@RestController
@CrossOrigin("*")
public class MDFUploadController {
	
	@Autowired
	MDFUploadHeaders headers;
	
	@GetMapping("/uploadHeaders")
	public ExcelHeaders uploadHeaders(@RequestBody ExcelHeaders excelHeaders) {
		return headers.uploadHeaders(excelHeaders);
	}
      
	@GetMapping("/getData")
	public ExcelHeaders getData() {
		ExcelHeaders data = headers.getData();
		Helper.getDbHeaders(data);
		return data;
	}
	
}
