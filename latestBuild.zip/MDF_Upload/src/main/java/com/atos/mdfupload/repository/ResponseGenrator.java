package com.atos.mdfupload.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface ResponseGenrator extends JpaRepository<com.atos.mdfupload.coustom.exception.ResponseGenrator, Integer> {

}
