package com.atos.mdfupload.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.atos.mdfupload.coustom.exception.ResponseGenrator;
import com.atos.mdfupload.coustom.exception.UserResponse;
import com.atos.mdfupload.helper.Helper;
import com.atos.mdfupload.service.StudentService;

@RestController
@CrossOrigin("*")
public class StudentController {
	private List<ResponseGenrator> xlsxFileUploadStatus=new ArrayList<ResponseGenrator>();
	@Autowired
	StudentService service;


	@PostMapping("/product/upload")
	public List<UserResponse> upload(@RequestParam("file") MultipartFile file) throws IOException {
		if (Helper.checkExcelFormat(file)) {
			xlsxFileUploadStatus = this.service.save(file);
		}
		return Helper.userResponse;
	}
	
	@GetMapping("/product/xlsxFileUploadStatus")
	public List<ResponseGenrator> upload(){
		return xlsxFileUploadStatus;
	}
}
