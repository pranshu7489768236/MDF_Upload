package com.atos.mdfupload.coustom.exception;

import java.util.List;

public class UserResponse {

	private String sms;
	private int status;
	private List<Object> data;

	public String getSms() {
		return sms;
	}

	public void setSms(String sms) {
		this.sms = sms;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public List<Object> getData() {
		return data;
	}

	public void setData(List<Object> data) {
		this.data = data;
	}

}
