package com.atos.mdfupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MdfUploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
