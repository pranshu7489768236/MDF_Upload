package com.netclip.online.quiz.service;

import com.netclip.online.quiz.user.dto.UserDto;

public interface UserService {

	public UserDto addUser(UserDto userDto);
}
