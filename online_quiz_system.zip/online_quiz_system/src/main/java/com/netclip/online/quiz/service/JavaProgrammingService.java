package com.netclip.online.quiz.service;

import org.springframework.data.domain.Page;

import com.netclip.online.quiz.dto.JavaPragramming;

public interface JavaProgrammingService {

	JavaPragramming addQuestions(JavaPragramming javaPragramming);

	Page<JavaPragramming> getJavaQuestions(int questionNum);

}
