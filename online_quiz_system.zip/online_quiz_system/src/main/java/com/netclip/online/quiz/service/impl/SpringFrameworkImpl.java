package com.netclip.online.quiz.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netclip.online.quiz.dao.IspringFramework;
import com.netclip.online.quiz.service.SpringFrameworkService;

@Service
public class SpringFrameworkImpl implements SpringFrameworkService {

	@Autowired
	IspringFramework ispringFramework;
}
