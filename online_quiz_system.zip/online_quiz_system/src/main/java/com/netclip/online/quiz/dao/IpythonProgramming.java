package com.netclip.online.quiz.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.netclip.online.quiz.dto.PythonProgramming;

@Repository
public interface IpythonProgramming extends JpaRepository<PythonProgramming, String>{

}
