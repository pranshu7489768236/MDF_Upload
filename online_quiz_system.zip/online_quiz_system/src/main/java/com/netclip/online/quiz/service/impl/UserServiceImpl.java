package com.netclip.online.quiz.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netclip.online.quiz.dao.UserServiceDao;
import com.netclip.online.quiz.service.UserService;
import com.netclip.online.quiz.user.dto.UserDto;
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserServiceDao dao;

	@Override
	public UserDto addUser(UserDto userDto) {
		return dao.save(userDto);
	}

}
