package com.netclip.online.quiz.service.impl;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.netclip.online.quiz.dao.IjavaProgramming;
import com.netclip.online.quiz.dto.JavaPragramming;
import com.netclip.online.quiz.service.JavaProgrammingService;

@Service
public class JavaProgrammingImpl implements JavaProgrammingService {

	@Autowired
	IjavaProgramming ijavaProgramming;

	@Override
	public JavaPragramming addQuestions(JavaPragramming javaPragramming) {
		javaPragramming.setQuestionId(UUID.randomUUID().toString());
		return ijavaProgramming.save(javaPragramming);
	}

	@Override
	public Page<JavaPragramming> getJavaQuestions(int questionNum) {
		return ijavaProgramming.findAll(PageRequest.of(questionNum, 1, Sort.by(Sort.Direction.DESC, "questionId")));
	}
}
