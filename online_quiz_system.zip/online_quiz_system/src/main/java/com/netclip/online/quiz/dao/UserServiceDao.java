package com.netclip.online.quiz.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.netclip.online.quiz.user.dto.UserDto;

@Repository
public interface UserServiceDao extends JpaRepository<UserDto, String> {

}
