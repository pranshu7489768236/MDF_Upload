package com.netclip.online.quiz.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.netclip.online.quiz.dto.JavaPragramming;
import com.netclip.online.quiz.service.JavaProgrammingService;

@RestController
@CrossOrigin("*")
@RequestMapping("online_quiz")
public class OnlineQuizController {

	
	@Autowired
	JavaProgrammingService javaProgrammingService;
	
	@PostMapping("/addQuestions")
	public JavaPragramming addQuestion(@RequestBody JavaPragramming javaPragramming) {
		return javaProgrammingService.addQuestions(javaPragramming);
	}
	
	@GetMapping("/getJavaQuestions")
	public Page<JavaPragramming> getJavaQuestions(@RequestParam int questionNum){
		System.out.println("pageNum : "+questionNum);
		return javaProgrammingService.getJavaQuestions(questionNum);
	}
}
