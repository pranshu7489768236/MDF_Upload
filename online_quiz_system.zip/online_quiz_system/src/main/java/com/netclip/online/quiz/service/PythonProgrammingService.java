package com.netclip.online.quiz.service;

public interface PythonProgrammingService {

}
