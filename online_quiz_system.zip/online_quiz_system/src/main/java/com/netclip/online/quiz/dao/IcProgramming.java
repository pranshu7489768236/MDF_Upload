package com.netclip.online.quiz.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.netclip.online.quiz.dto.CProgramming;

@Repository
public interface IcProgramming extends JpaRepository<CProgramming, String>{

}
