package com.netclip.online.quiz.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netclip.online.quiz.dao.IpythonProgramming;
import com.netclip.online.quiz.service.PythonProgrammingService;

@Service
public class PythonProgrammingImpl implements PythonProgrammingService {

	@Autowired
	IpythonProgramming ipythonProgramming;
}
