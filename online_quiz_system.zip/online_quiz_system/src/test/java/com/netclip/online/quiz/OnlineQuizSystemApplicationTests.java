package com.netclip.online.quiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineQuizSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
