package com.atos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManagmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
