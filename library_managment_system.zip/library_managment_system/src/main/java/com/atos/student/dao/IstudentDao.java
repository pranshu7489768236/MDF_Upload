package com.atos.student.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.atos.student.dto.StudentDto;
@Repository
public interface IstudentDao extends JpaRepository<StudentDto, String> {

	public StudentDto findByStudentId(String userName);

}
