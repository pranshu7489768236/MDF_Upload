package com.atos.student.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.atos.student.dto.BookStore;

public interface IbookStoreService {

	Page<BookStore> getAllBooks(int offset, int limit);

	BookStore addNewBook(BookStore bookStore);

	BookStore increseNumberOfBooks(String isbn);

	BookStore decreaseNumberOfBooks(String isbn);

}
