package com.atos.student.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.atos.student.dto.BookStore;
@Repository
public interface IbookStoreDao extends JpaRepository<BookStore, String> {


	BookStore findByIsbn(String isbn);


}
