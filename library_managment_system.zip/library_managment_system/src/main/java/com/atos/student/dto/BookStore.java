package com.atos.student.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "BooksCollection")
public class BookStore {
	@Id
	private String isbn;
	private String title;
	private String author;
	private int availity;
	
	public String getException() {
		return exception;
	}

	public void setException(String exception) {
		this.exception = exception;
	}

	private String exception;

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getAvaility() {
		return availity;
	}

	public void setAvaility(int availity) {
		this.availity = availity;
	}

	@Override
	public String toString() {
		return "BookStore [isbn=" + isbn + ", title=" + title + ", author=" + author + ", availity=" + availity
				+ ", exception=" + exception + "]";
	}


}
