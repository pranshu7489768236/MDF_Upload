package com.atos.student.service.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atos.student.dao.IuserRequestDao;
import com.atos.student.dto.UserRequest;
import com.atos.student.service.IuserRequerstService;

@Service
public class UserRequerstServiceImpl implements IuserRequerstService {

	@Autowired
	IuserRequestDao userRequestDao;

	UserRequest userRequest = new UserRequest();

	@Override
	public UserRequest raiseTicket(String massage, String tempUserName) {
		userRequest.setTicketId(UUID.randomUUID().toString());
		userRequest.setStudentid(tempUserName);
		userRequest.setUserRequestSms(massage);
		return userRequestDao.save(userRequest);
	}

	@Override
	public int rejectUserRequestMassage(String rejectUserRequestMassage, String tempTicketId) {
		return userRequestDao.rejectUserRequestMassage(rejectUserRequestMassage, tempTicketId);
	}

	@Override
	public boolean isStudentPendingTicket(String studentId) {
		long count = userRequestDao.existByStudentId(studentId);
		if (count == 0) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public int givePermissionToUser(String tickedId) {
		return userRequestDao.givePermissionToUser(tickedId);
	}

	@Override
	public UserRequest isAdminMassage(String tempUsername) {
		return userRequestDao.isAdminMassage(tempUsername);
		
	}
}
