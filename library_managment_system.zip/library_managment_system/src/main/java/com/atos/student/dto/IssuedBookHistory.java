package com.atos.student.dto;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Student_Issued_Book_Details")
public class IssuedBookHistory {

	
	private String studentId;
	@Id
	private int s_no;
	private String isbn;
	private LocalDate book_issue_date;
	private LocalDate book_renew_date;
	private int fine;

	public String getStudentId() {
		return studentId;
	}
	public int getS_no() {
		return s_no;
	}

	public void setS_no(int s_no) {
		this.s_no = s_no;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public LocalDate getBook_issue_date() {
		return book_issue_date;
	}

	public void setBook_issue_date(LocalDate string) {
		this.book_issue_date = string;
	}

	public LocalDate getBook_renew_date() {
		return book_renew_date;
	}

	public void setBook_renew_date(LocalDate book_renew_date) {
		this.book_renew_date = book_renew_date;
	}

	public int getFine() {
		return fine;
	}

	public void setFine(int fine) {
		this.fine = fine;
	}
	@Override
	public String toString() {
		return "IssuedBookHistory [studentId=" + studentId + ", s_no=" + s_no + ", isbn=" + isbn + ", book_issue_date="
				+ book_issue_date + ", book_renew_date=" + book_renew_date + ", fine=" + fine + "]";
	}

	
}
