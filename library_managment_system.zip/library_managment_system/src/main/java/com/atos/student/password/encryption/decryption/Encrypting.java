package com.atos.student.password.encryption.decryption;

public class Encrypting {

	
	public static String getEncryption(String password) {
		String encrypt="";
		for(int i=0;i<password.length();i++) {
			char ch = password.charAt(i);
			ch+=8;
			encrypt+=ch;
		}
		return encrypt;
	}
	
	
	public static String getDecryption(String password) {
		String decrypt="";
		for(int i=0;i<password.length();i++) {
			char ch = password.charAt(i);
			ch-=8;
			decrypt+=ch;
		}
		return decrypt;
	}
}
