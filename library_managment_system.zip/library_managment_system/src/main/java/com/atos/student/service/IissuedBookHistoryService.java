package com.atos.student.service;

import java.util.List;

import com.atos.student.dto.IssuedBookHistory;

public interface IissuedBookHistoryService {

	IssuedBookHistory issuedBooks(String isbn, String tempUsername);

	int payFineAndDeleteBook(int s_no);

	List<IssuedBookHistory> getStudentlibraryDetails(String studentId);

}
