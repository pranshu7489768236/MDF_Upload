package com.atos.student.password.encryption.decryption;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;

public class DateLogic {

	public static String getCurrentDate() {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		return formatter.format(date);
	}

	public static String getRenewDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, 15);
		String renewDate = sdf.format(cal.getTime());
		return renewDate;
	}

	public static long getFine(String renewDate) throws ParseException {
		// Parsing the date
		LocalDate dateBefore = LocalDate.now();
		LocalDate dateAfter = LocalDate.parse(renewDate);
		// calculating number of days in between
		long noOfDaysBetween = ChronoUnit.DAYS.between(dateAfter, dateBefore);
		return noOfDaysBetween * 5;
	}

	// this method return boolean value if current date greaterthan renew date.
	public static boolean dateCheker(String renewDate) {
		boolean result = false;
		try {
			String currentDate = LocalDate.now() + "";
			Date start = new SimpleDateFormat("yyyy-MM-dd").parse(currentDate);
			Date end = new SimpleDateFormat("yyyy-MM-dd").parse(renewDate);
			if (start.compareTo(end) > 0) {
				result = true;
			} else if (start.compareTo(end) < 0) {
				result = false;
			}

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return result;
	}
}
