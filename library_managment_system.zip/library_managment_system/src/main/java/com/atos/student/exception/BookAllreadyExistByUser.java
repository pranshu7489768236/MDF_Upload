package com.atos.student.exception;

public class BookAllreadyExistByUser extends RuntimeException {

	public BookAllreadyExistByUser(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
