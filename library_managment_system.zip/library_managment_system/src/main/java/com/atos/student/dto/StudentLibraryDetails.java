package com.atos.student.dto;

public class StudentLibraryDetails {
	private String isbn;
	private int fine;

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public int getFine() {
		return fine;
	}

	public void setFine(int fine) {
		this.fine = fine;
	}

	@Override
	public String toString() {
		return "StudentLibraryDetails [isbn=" + isbn + ", fine=" + fine + "]";
	}

}
