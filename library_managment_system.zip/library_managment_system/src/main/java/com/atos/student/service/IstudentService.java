package com.atos.student.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.atos.student.dto.BookStore;
import com.atos.student.dto.IssuedBookHistory;
import com.atos.student.dto.StudentDto;
import com.atos.student.dto.UserRequest;

public interface IstudentService {

	StudentDto createUserAccount(StudentDto studentDto);

	StudentDto validateUser(String email, String password);

	StudentDto getUserDetails(String tempUsername);

	List<IssuedBookHistory> getAllIssuedBooks(String studentId);

	StudentDto updateUserPassword(String password, String tempUsername);

	Page<StudentDto> getStudentDetailsList(int offset);

	List<UserRequest> getStudentRequestData();

	Page<BookStore> getBooksTableData(int offset);

	void deleteAccount(String studentId); 


	
	
}
