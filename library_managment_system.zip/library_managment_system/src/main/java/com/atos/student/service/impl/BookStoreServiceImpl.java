package com.atos.student.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.atos.student.dao.IbookStoreDao;
import com.atos.student.dto.BookStore;
import com.atos.student.service.IbookStoreService;

@Service
public class BookStoreServiceImpl implements IbookStoreService {

	@Autowired
	IbookStoreDao bookStoreDao;

	@Override
	public Page<BookStore> getAllBooks(int offset, int limit) {
		return bookStoreDao.findAll(PageRequest.of(offset, 5, Sort.by(Sort.Direction.DESC, "isbn")));
	}

	@Override
	public BookStore addNewBook(BookStore bookStore) {
		return bookStoreDao.save(bookStore);
	}

	@Override
	public BookStore increseNumberOfBooks(String isbn) {
		  BookStore book = bookStoreDao.findByIsbn(isbn);
		  book.setAvaility(book.getAvaility()+1);
		return bookStoreDao.save(book);
	}

	@Override
	public BookStore decreaseNumberOfBooks(String isbn) {
		BookStore book = bookStoreDao.findByIsbn(isbn);
		  book.setAvaility(book.getAvaility()-1);
		return bookStoreDao.save(book);
	}
}
