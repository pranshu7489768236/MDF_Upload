package com.atos.student.service.impl;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atos.student.dao.IbookStoreDao;
import com.atos.student.dao.IissuedBookHistoryDao;
import com.atos.student.dto.BookStore;
import com.atos.student.dto.IssuedBookHistory;
import com.atos.student.exception.BookAllreadyExistByUser;
import com.atos.student.service.IissuedBookHistoryService;

@Service
public class IssuedBookHistoryServiceImpl implements IissuedBookHistoryService {

	private IssuedBookHistory issuedBookHistory = new IssuedBookHistory();

	@Autowired
	IissuedBookHistoryDao issuedBookHistoryRepo;

	@Autowired
	IbookStoreDao bookStoreRepo;

	@Override
	public IssuedBookHistory issuedBooks(String isbn, String tempUsername) {
		if (issuedBookHistoryRepo.userBookExist(isbn, tempUsername) == 0) {
			issuedBookHistory.setStudentId(tempUsername);
			issuedBookHistory.setS_no((issuedBookHistoryRepo.findmax()) + 1);
			issuedBookHistory.setIsbn(isbn);
			issuedBookHistory.setBook_issue_date(LocalDate.now());
			issuedBookHistory.setBook_renew_date(LocalDate.now().plusDays(15));
			issuedBookHistory.setFine(0);
			BookStore findById = bookStoreRepo.findByIsbn(isbn);
			findById.setAvaility((findById.getAvaility() - 1));
			bookStoreRepo.save(findById);
			return issuedBookHistoryRepo.save(issuedBookHistory);
		} else {
			throw new BookAllreadyExistByUser("You have Allready Issued this book");
		}

	}

	@Override
	public int payFineAndDeleteBook(int s_no) {
		issuedBookHistoryRepo.deleteById(s_no);
		return 1;
	}

	@Override
	public List<IssuedBookHistory> getStudentlibraryDetails(String studentId) {
		return issuedBookHistoryRepo.findByStudentId(studentId);
	}
}
