package com.atos.student.service.impl;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.atos.student.dao.IbookStoreDao;
import com.atos.student.dao.IissuedBookHistoryDao;
import com.atos.student.dao.IstudentDao;
import com.atos.student.dao.IuserRequestDao;
import com.atos.student.dto.BookStore;
import com.atos.student.dto.IssuedBookHistory;
import com.atos.student.dto.StudentDto;
import com.atos.student.dto.UserRequest;
import com.atos.student.password.encryption.decryption.DateLogic;
import com.atos.student.password.encryption.decryption.Encrypting;
import com.atos.student.service.IstudentService;

@Service
public class StudentServiceImpl implements IstudentService {

	@Autowired
	IstudentDao istudentDao;

	@Autowired
	IissuedBookHistoryDao issuedBookHistoryDao;
	
	@Autowired
	IuserRequestDao iuserRequestDao;
	
	@Autowired
	IbookStoreDao ibookStoreDao;

	@Override
	public StudentDto createUserAccount(StudentDto studentDto) {
		studentDto.setPassword("012345678");
		studentDto.setPassword(Encrypting.getEncryption(studentDto.getPassword()));
		istudentDao.save(studentDto);
		return studentDto;
	}

	@Override
	public StudentDto validateUser(String userName, String password) {
		if (istudentDao.existsById(userName)) {
			calculateLibraryFine(userName);// if user exist then call this method.
			StudentDto studentDto = istudentDao.findByStudentId(userName);
			if ((Encrypting.getDecryption(studentDto.getPassword())).equals(password)) {
				return studentDto;
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	@Override
	public StudentDto getUserDetails(String tempUsername) {
		return istudentDao.findByStudentId(tempUsername);
	}

	@Override
	public List<IssuedBookHistory> getAllIssuedBooks(String studentId) {
		return issuedBookHistoryDao.findByStudentId(studentId);
	}

	@Override
	public StudentDto updateUserPassword(String password, String tempUsername) {
		StudentDto student = istudentDao.findByStudentId(tempUsername);
		student.setPassword(Encrypting.getEncryption(password));
		return istudentDao.save(student);
	}

	// this method should be run when user logedin and calculate the user library
	// fine.
	public void calculateLibraryFine(String userName) {
		try {
			List<IssuedBookHistory> user = issuedBookHistoryDao.findByStudentId(userName);
			for (IssuedBookHistory issuedBookHistory : user) {
				if (DateLogic.dateCheker(issuedBookHistory.getBook_renew_date() + "")) {
					issuedBookHistory.setFine((int) DateLogic.getFine(issuedBookHistory.getBook_renew_date() + ""));
				}
			}
			issuedBookHistoryDao.saveAll(user);
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	@Override
	public Page<StudentDto> getStudentDetailsList(int offset) {
		return istudentDao.findAll(PageRequest.of(offset, 5, Sort.by(Sort.Direction.DESC, "studentId")));
	}

	@Override
	public List<UserRequest> getStudentRequestData() {
		return iuserRequestDao.findAll();
	}

	@Override
	public Page<BookStore> getBooksTableData(int offset) {
		return ibookStoreDao.findAll(PageRequest.of(offset, 5, Sort.by(Sort.Direction.DESC, "isbn")));
	}

	@Override
	public void deleteAccount(String studentId) {
		issuedBookHistoryDao.deleteByStudentId(studentId);
		iuserRequestDao.deleteByStudentId(studentId);
		istudentDao.deleteById(studentId);
		
	}

}
