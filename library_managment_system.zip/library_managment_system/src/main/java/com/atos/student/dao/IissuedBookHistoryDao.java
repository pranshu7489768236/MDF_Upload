package com.atos.student.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.atos.student.dto.IssuedBookHistory;
@Repository
public interface IissuedBookHistoryDao extends JpaRepository<IssuedBookHistory, Integer> {
    @Query("SELECT I FROM IssuedBookHistory I WHERE I.studentId=?1")
	List<IssuedBookHistory> findByStudentId(String studentId);

	IssuedBookHistory findByIsbn(String isbn);
    @Query("SELECT max(s_no) FROM IssuedBookHistory")
	int findmax();
    @Query("SELECT count(*) from IssuedBookHistory where isbn=?1 and studentId=?2")
	int userBookExist(String isbn, String tempUsername);

    @Query("DELETE FROM IssuedBookHistory WHERE studentId=?1")
    @Transactional
	@Modifying
	void deleteByStudentId(String studentId);


}
