package com.atos.student.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.atos.student.dto.UserRequest;
@Repository
public interface IuserRequestDao extends JpaRepository<UserRequest,String> {

	@Query("UPDATE UserRequest SET adminMassage=?1 where ticketId=?2")
	@Transactional
	@Modifying
	int rejectUserRequestMassage(String rejectUserRequestMassage, String tempTicketId);

	@Query("SELECT count(*) from UserRequest where studentid=?1 and adminPermision=false")
	long existByStudentId(String studentId);

	@Query("UPDATE UserRequest SET adminPermision=true,adminMassage='permission granted',adminPermisionStatus=1 where ticketId=?1")
	@Transactional
	@Modifying
	int givePermissionToUser(String tickedId);

	@Query("select i from UserRequest i where i.studentid=?1 and adminMassage IS NOT NULL")
	UserRequest isAdminMassage(String studentid);

	@Query("DELETE FROM UserRequest WHERE studentId=?1")
	@Transactional
	@Modifying
	void deleteByStudentId(String studentId);
}
