package com.atos.student.service;

import java.util.List;
import java.util.UUID;

import com.atos.student.dto.UserRequest;

public interface IuserRequerstService {


	UserRequest raiseTicket(String massage, String tempUserName);

	int rejectUserRequestMassage(String rejectUserRequestMassage, String tempTicketId);

	boolean isStudentPendingTicket(String studentId);

	int givePermissionToUser(String tickedId);

	UserRequest isAdminMassage(String tempUsername);

}
