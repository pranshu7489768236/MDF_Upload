package com.atos.student.dto;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Student_request_details")
public class UserRequest {
	@Id
	private String ticketId;
	private String studentid;
	private String userRequestSms;
	private boolean adminPermision;
	private String adminMassage;
    private int adminPermisionStatus;
	public String getTicketId() {
		return ticketId;
	}

	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}

	public boolean isAdminPermision() {
		return adminPermision;
	}

	public void setAdminPermision(boolean adminPermision) {
		this.adminPermision = adminPermision;
	}

	public String getStudentid() {
		return studentid;
	}

	public void setStudentid(String studentid) {
		this.studentid = studentid;
	}

	public String getUserRequestSms() {
		return userRequestSms;
	}

	public void setUserRequestSms(String userRequestSms) {
		this.userRequestSms = userRequestSms;
	}

	public String getAdminMassage() {
		return adminMassage;
	}

	public void setAdminMassage(String adminMassage) {
		this.adminMassage = adminMassage;
	}
	

	public int getAdminPermisionStatus() {
		return adminPermisionStatus;
	}

	public void setAdminPermisionStatus(int adminPermisionStatus) {
		this.adminPermisionStatus = adminPermisionStatus;
	}

	@Override
	public String toString() {
		return "UserRequest [ticketId=" + ticketId + ", studentid=" + studentid + ", userRequestSms=" + userRequestSms
				+ ", adminPermision=" + adminPermision + ", adminMassage=" + adminMassage + "]";
	}

}
