package com.atos.library.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.atos.admin.dto.AdminDto;
import com.atos.admin.service.IadminService;
import com.atos.student.dao.IissuedBookHistoryDao;
import com.atos.student.dto.BookStore;
import com.atos.student.dto.IssuedBookHistory;
import com.atos.student.dto.StudentDto;
import com.atos.student.dto.UserRequest;
import com.atos.student.service.IbookStoreService;
import com.atos.student.service.IissuedBookHistoryService;
import com.atos.student.service.IstudentService;
import com.atos.student.service.IuserRequerstService;

@RequestMapping("/admin")
@CrossOrigin("*")
@RestController
public class AdminController {
	private List<AdminDto> adminDetails = new ArrayList();
	private String tempTicketId;
	@Autowired
	IadminService iadminService;
	@Autowired
	IstudentService istudentService;

	@Autowired
	IbookStoreService ibookStoreService;

	@Autowired
	IissuedBookHistoryService iissuedBookHistoryService;

	@Autowired
	IuserRequerstService iuserRequerstService;

	@GetMapping("/adminLogin")
	public AdminDto getLogin(@RequestParam String adminId, String password) {
		AdminDto admin = iadminService.validateAdmin(adminId, password);
		adminDetails.add(admin);
		return iadminService.validateAdmin(adminId, password);
	}

	@GetMapping("/getAdminDetails")
	public List<AdminDto> getAminDetails() {
		return adminDetails;
	}

	@GetMapping("/getTotalNumberOfBooks")
	public long getTotalNumberOfBooks() {
		return iadminService.getTotalNumberOfBooks();
	}

	@GetMapping("/getTotalNumberOfStudents")
	public long getTotalNumberOfStudents() {
		return iadminService.getTotalNumberOfStudents();
	}

	@GetMapping("/getTotalNumberOfRequest")
	public long getTotalNumberOfRequest() {
		return iadminService.getTotalNumberOfRequest();
	}

	@GetMapping("/getStudentDetailsList")
	public Page<StudentDto> getStudentDetailsList(@RequestParam int offset) {
		return istudentService.getStudentDetailsList(offset);
	}

	@GetMapping("/getStudentRequestData")
	public List<UserRequest> getStudentRequestData() {
		return istudentService.getStudentRequestData();
	}

	@GetMapping("/getBooksTableData")
	public Page<BookStore> getBooksTableData(@RequestParam int offset) {
		return istudentService.getBooksTableData(offset);
	}

	@PostMapping("/addNewBook")
	public BookStore addNewBook(@RequestBody BookStore bookStore) {
		return ibookStoreService.addNewBook(bookStore);
	}

	@GetMapping("/increseNumberOfBooks")
	public BookStore increseNumberOfBooks(@RequestParam String isbn) {
		return ibookStoreService.increseNumberOfBooks(isbn);
	}

	@GetMapping("/decreaseNumberOfBooks")
	public BookStore decreaseNumberOfBooks(@RequestParam String isbn) {
		return ibookStoreService.decreaseNumberOfBooks(isbn);
	}

	@GetMapping("/getStudentlibraryDetails")
	public List<IssuedBookHistory> getStudentlibraryDetails(@RequestParam String studentId, String ticketId) {
		this.tempTicketId = ticketId;// store ticketId for feature use.
		return iissuedBookHistoryService.getStudentlibraryDetails(studentId);
	}

	@PutMapping("/rejectUserRequestMassage")
	public int rejectUserRequestMassage(@RequestParam String rejectUserRequestMassage) {
		return iuserRequerstService.rejectUserRequestMassage(rejectUserRequestMassage, this.tempTicketId);
	}

	@GetMapping("/givePermissionToUser")
	public int givePermissionToUser(@RequestParam String tickedId) {
		return iuserRequerstService.givePermissionToUser(tickedId);
	}

}
