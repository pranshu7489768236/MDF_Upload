package com.atos.library.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.atos.student.dto.IssuedBookHistory;
import com.atos.student.dto.StudentDto;
import com.atos.student.dto.UserRequest;
import com.atos.student.service.IissuedBookHistoryService;
import com.atos.student.service.IstudentService;
import com.atos.student.service.IuserRequerstService;

@RestController
@CrossOrigin("*")
@RequestMapping("user")
public class StudentController {
	private int i;
	private String tempUsername;
	private List<UserRequest> adminMassageList = new ArrayList();
	private List<StudentDto> userDetailsList = new ArrayList<>();

	@Autowired
	IstudentService studentService;

	@Autowired
	IissuedBookHistoryService issueBookHistoryService;

	@Autowired
	IuserRequerstService iuserRequerstService;

	@PostMapping("/registration")
	public StudentDto createStudentAccount(@RequestBody StudentDto studentDto) {
		return studentService.createUserAccount(studentDto);
	}

	@GetMapping("/login")
	public StudentDto getLoginDetails(@RequestParam String email, String password) {
		// initializing the variable with current userId for the feature use.
		tempUsername = email;
		return studentService.validateUser(email, password);
	}

	@GetMapping("/isAdminMassage")
	public UserRequest isAdminMassage() {
		UserRequest adminMassage = iuserRequerstService.isAdminMassage(tempUsername);
		if (adminMassageList.size() < 1) {// restiction to reasign list.
			adminMassageList.add(adminMassage);// store admin massage for feature use.
		}
		return adminMassage;
	}

	@GetMapping("/getUserRequestStatus")
	public List<UserRequest> getUserRequestStatus() {
		if (adminMassageList.get(0) == null) {
			adminMassageList.remove(0);
		}
		return adminMassageList;
	}

	@GetMapping("/getUserData")
	public List<StudentDto> getUserDetails() {
		if (userDetailsList.size() == 0) {
			userDetailsList.add(studentService.getUserDetails(this.tempUsername));
			return userDetailsList;
		} else {
			return this.userDetailsList;
		}
	}

	@GetMapping("/getAllIssuedBooks")
	public List<IssuedBookHistory> getAllIssuedBooks() {
		return studentService.getAllIssuedBooks(this.tempUsername);
	}

	@GetMapping("/issueBook")
	public IssuedBookHistory issueBook(@RequestParam String isbn) {
		return issueBookHistoryService.issuedBooks(isbn, tempUsername);
	}

	@DeleteMapping("/userRaiseTicket")
	public UserRequest raiseTicket(@RequestParam String massage) {
		return iuserRequerstService.raiseTicket(massage, tempUsername);
	}

	@DeleteMapping("/payFineAmount")
	public int payFineAndDeleteBook(@RequestParam int s_no) {
		return issueBookHistoryService.payFineAndDeleteBook(s_no);
	}

	@PutMapping("/resetPassword")
	public StudentDto updateUserPassword(@RequestParam String password) {
		return studentService.updateUserPassword(password, tempUsername);
	}

	@GetMapping("/isStudentPendingTicket")
	public boolean isStudentPendingTicket(@RequestParam String studentId) {
		return iuserRequerstService.isStudentPendingTicket(studentId);
	}

	@DeleteMapping("/deleteAccount")
	public int deleteAccount(@RequestParam String studentId) {
		studentService.deleteAccount(studentId);
		logout();
		return 1;
	}

	@GetMapping("/logOut")
	public void logout() {
		userDetailsList = new ArrayList<>();
		adminMassageList = new ArrayList<>();
		tempUsername = null;
	}
}
