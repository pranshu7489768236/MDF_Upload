package com.atos.admin.service;

import com.atos.admin.dto.AdminDto;

public interface IadminService {

	public AdminDto validateAdmin(String adminId, String password);

	public long getTotalNumberOfBooks();

	public long getTotalNumberOfStudents();

	public long getTotalNumberOfRequest();
}
