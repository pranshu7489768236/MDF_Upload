package com.atos.admin.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atos.admin.dao.IadminDao;
import com.atos.admin.dto.AdminDto;
import com.atos.admin.service.IadminService;
import com.atos.student.dao.IbookStoreDao;
import com.atos.student.dao.IstudentDao;
import com.atos.student.dao.IuserRequestDao;
import com.atos.student.password.encryption.decryption.Encrypting;

@Service
public class AdminServiceImpl implements IadminService {

	@Autowired
	IadminDao iadminDao;

	@Autowired
	IbookStoreDao ibookStoreDao;

	@Autowired
	IstudentDao istudentDao;

	@Autowired
	IuserRequestDao iuserRequestDao;

	@Override
	public AdminDto validateAdmin(String adminId, String password) {
		System.out.println(adminId);
		if (iadminDao.existsById(adminId)) {
			AdminDto admin = iadminDao.findByAdminId(adminId);
			if ((Encrypting.getDecryption(admin.getPassword())).equals(password)) {
				System.out.println("successfull : " + adminId);
				return admin;
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	@Override
	public long getTotalNumberOfBooks() {
		return ibookStoreDao.count();
	}

	@Override
	public long getTotalNumberOfStudents() {
		return istudentDao.count();
	}

	@Override
	public long getTotalNumberOfRequest() {
		return iuserRequestDao.count();
	}

}
