package com.atos.admin.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.atos.admin.dto.AdminDto;

@Repository
public interface IadminDao extends JpaRepository<AdminDto, String> {

	AdminDto findByAdminId(String adminId);

}
