package com.controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;

@Repository
public class Connectivity {

	EntityManagerFactory factory;
	EntityManager manager;
	EntityTransaction transaction;

	public StudentEntity add(StudentEntity entity) {
		factory = Persistence.createEntityManagerFactory("r");
		manager = factory.createEntityManager();
		transaction=manager.getTransaction();
		transaction.begin();
		manager.persist(entity);
		transaction.commit();
		return entity;
	}
}
